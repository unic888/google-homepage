import { useState } from 'react';
import { Search, ChevronDown, ChevronRight } from 'lucide-react';
import { Input } from '@/app/components/ui/input';
import { Badge } from '@/app/components/ui/badge';

interface Distribution {
  id: string;
  name: string;
  version: string;
  build: string;
  packageName?: string;
  bundleId?: string;
  nexusUrl?: string;
  nexusSha?: string;
  fileSha: string;
  severity: {
    crit: number;
    high: number;
    med: number;
    low: number;
  };
}

interface PackageGroup {
  id: string;
  packageId: string;
  distributions: Distribution[];
}

interface Project {
  id: string;
  name: string;
  platform: 'iOS' | 'Android';
  packageGroups: PackageGroup[];
}

interface Product {
  id: string;
  name: string;
  projects: Project[];
}

const products: Product[] = [
  {
    id: 'drug',
    name: 'Друг',
    projects: [
      {
        id: 'drug-ios',
        name: 'Друг iOS',
        platform: 'iOS',
        packageGroups: [
          {
            id: 'drug-ios-pg1',
            packageId: 'ru.mast.drug.dev',
            distributions: [
              { 
                id: 'drug-ios-d1', 
                name: 'dev_CI0001001.ipa', 
                version: 'v1.0.0', 
                build: 'build 100', 
                bundleId: 'ru.mast.drug.dev',
                fileSha: 'fbb357e63638dc91cc7bb2e8aba0d6b0e9e7e7b8522f49288a354b532d6e307a',
                severity: { crit: 0, high: 0, med: 1, low: 2 } 
              },
            ],
          },
          {
            id: 'drug-ios-pg2',
            packageId: 'ru.mast.drug.ift',
            distributions: [
              { 
                id: 'drug-ios-d2', 
                name: 'ift_CI0001002.ipa', 
                version: 'v1.1.0', 
                build: 'build 110', 
                bundleId: 'ru.mast.drug.ift',
                nexusUrl: 'nexus.mycompany.com/CI00634192/CI00515198/D-26.001.64',
                nexusSha: '7e56a5f300e0763e94a2d9eba6517523e9bae3ef4657c5de11b696d13643e6fb',
                fileSha: '9b0ad768e93778f8fdcca1bba2dae536ab65efa36bac7a3899a731ea31d57dfb',
                severity: { crit: 0, high: 1, med: 1, low: 3 } 
              },
            ],
          },
          {
            id: 'drug-ios-pg3',
            packageId: 'ru.mast.drug.psi',
            distributions: [
              { 
                id: 'drug-ios-d3', 
                name: 'psi_CI0001003.ipa', 
                version: 'v1.2.0', 
                build: 'build 120', 
                bundleId: 'ru.mast.drug.psi',
                nexusUrl: 'nexus.mycompany.com/CI00299096/CI00557333/D-26.001.35',
                nexusSha: '576cef2086138d79f4230a2753aeccd3edb1a402cf7d391d1ef8e87bd973a50d',
                fileSha: '45883eb1e0fb5e3f8176f775393a2bc63f54b27f46b5e8b2e1afc8f6c438e724',
                severity: { crit: 0, high: 0, med: 2, low: 4 } 
              },
            ],
          },
          {
            id: 'drug-ios-pg4',
            packageId: 'ru.mast.drug.prod',
            distributions: [
              { 
                id: 'drug-ios-d4', 
                name: 'prod_CI0001004.ipa', 
                version: 'v1.3.0', 
                build: 'build 130', 
                bundleId: 'ru.mast.drug.prod',
                nexusUrl: 'nexus.mycompany.com/CI00380263/CI00713883/D-26.001.72',
                nexusSha: 'c0e0c497d616700c89831bf02212403f6818030344a6276ec5fd163017c7d70b',
                fileSha: 'eb56e12001fbd9ed706e55449089566b854312c33752a18e48dad8d1334fcf1f',
                severity: { crit: 0, high: 0, med: 1, low: 2 } 
              },
            ],
          },
        ],
      },
      {
        id: 'drug-android',
        name: 'Друг Android',
        platform: 'Android',
        packageGroups: [
          {
            id: 'drug-android-pg1',
            packageId: 'ru.mast.drug.dev',
            distributions: [
              { 
                id: 'drug-android-d1', 
                name: 'dev_CI0002001.apk', 
                version: 'v1.0.0', 
                build: 'build 200', 
                packageName: 'ru.mast.drug.dev',
                fileSha: '8c7ae49cc3abdbcc979e435bc0cf56554be967b1ccaf4b843bf9c01df88ad443',
                severity: { crit: 1, high: 2, med: 1, low: 3 } 
              },
            ],
          },
          {
            id: 'drug-android-pg2',
            packageId: 'ru.mast.drug.ift',
            distributions: [
              { 
                id: 'drug-android-d2', 
                name: 'ift_CI0002002.apk', 
                version: 'v1.1.0', 
                build: 'build 210', 
                packageName: 'ru.mast.drug.ift',
                nexusUrl: 'nexus.mycompany.com/CI00913912/CI00327473/D-26.001.97',
                nexusSha: 'afeb8b6dc1c94ecb28cfd099bd6dc53d8a0d4ae393eae771a61350a17a1e8f37',
                fileSha: 'd4ca5219e1c1c85c5c0908903664b3b5021673b24652274dfabc8d38538dcda3',
                severity: { crit: 0, high: 1, med: 2, low: 5 } 
              },
            ],
          },
          {
            id: 'drug-android-pg3',
            packageId: 'ru.mast.drug.psi',
            distributions: [
              { 
                id: 'drug-android-d3', 
                name: 'psi_CI0002003.apk', 
                version: 'v1.2.0', 
                build: 'build 220', 
                packageName: 'ru.mast.drug.psi',
                nexusUrl: 'nexus.mycompany.com/CI00196799/CI00119662/D-26.001.66',
                nexusSha: '12b648fec6d3523edb5283de052141b3111ea1b204cd2416957b323b4978f1b4',
                fileSha: 'b820707dc58e90b15f3e703ee1db4f1a6d08da352f481db90f57e2e436172a56',
                severity: { crit: 0, high: 0, med: 1, low: 2 } 
              },
            ],
          },
          {
            id: 'drug-android-pg4',
            packageId: 'ru.mast.drug.prod',
            distributions: [
              { 
                id: 'drug-android-d4', 
                name: 'prod_CI0002004.apk', 
                version: 'v1.3.0', 
                build: 'build 230', 
                packageName: 'ru.mast.drug.prod',
                nexusUrl: 'nexus.mycompany.com/CI00242465/CI00487325/D-26.001.62',
                nexusSha: 'fe8bca1ed8f96a06b0ce78be3145233a477df7aa04e7a677c3266aebe3d34f2c',
                fileSha: 'afb6e6727b05961956663cf254f785ad1a4d690fe5e0a80a75cad0b26ffce5c0',
                severity: { crit: 0, high: 0, med: 1, low: 2 } 
              },
            ],
          },
        ],
      },
    ],
  },
  {
    id: 'otp',
    name: 'OTP',
    projects: [
      {
        id: 'otp-ios',
        name: 'OTP iOS',
        platform: 'iOS',
        packageGroups: [
          {
            id: 'otp-ios-pg1',
            packageId: 'ru.mast.otp.ios',
            distributions: [
              { 
                id: 'otp-ios-d1', 
                name: 'dev_CI0003001.ipa', 
                version: 'v2.0.0', 
                build: 'build 300', 
                bundleId: 'ru.mast.otp.ios',
                fileSha: '37caa31021c9c984cbcffbe17a8b95868791a05d8db925bf74b44df89acb46d4',
                severity: { crit: 0, high: 0, med: 1, low: 1 } 
              },
              { 
                id: 'otp-ios-d2', 
                name: 'ift_CI0003002.ipa', 
                version: 'v2.1.0', 
                build: 'build 310', 
                bundleId: 'ru.mast.otp.ios',
                nexusUrl: 'nexus.mycompany.com/CI00718772/CI00490840/D-26.001.16',
                nexusSha: '9160d876b54f8e15370b398f1f3505994156f7c9566f0a6fb1b639998ee6d254',
                fileSha: 'bf5094dddfd83ca3c34c671cc19b9e28f9cae40114f4e2f6733f7619e85889ea',
                severity: { crit: 0, high: 1, med: 0, low: 2 } 
              },
              { 
                id: 'otp-ios-d3', 
                name: 'psi_CI0003003.ipa', 
                version: 'v2.2.0', 
                build: 'build 320', 
                bundleId: 'ru.mast.otp.ios',
                nexusUrl: 'nexus.mycompany.com/CI00756364/CI00341149/D-26.001.18',
                nexusSha: 'f2516b1854f4435dc4774ac0b67b0ff1138b7ff272cf8143c66970b874026366',
                fileSha: '5f07213b5ee285bf566f762f229a60e6a08c89d8e91af3ae0626e379c34091cd',
                severity: { crit: 0, high: 0, med: 2, low: 3 } 
              },
              { 
                id: 'otp-ios-d4', 
                name: 'prod_CI0003004.ipa', 
                version: 'v2.3.0', 
                build: 'build 330', 
                bundleId: 'ru.mast.otp.ios',
                nexusUrl: 'nexus.mycompany.com/CI00352852/CI00590646/D-26.001.06',
                nexusSha: '598d76ba87eee3a851f28188e3831a0d3126d3fd41773c0b3a11d7d87ac121db',
                fileSha: 'e464c486b6b112c27adbc2559d6a8e6b75d58bf084dca7d74267c543aa0b3572',
                severity: { crit: 0, high: 0, med: 1, low: 2 } 
              },
            ],
          },
        ],
      },
      {
        id: 'otp-android',
        name: 'OTP Android',
        platform: 'Android',
        packageGroups: [
          {
            id: 'otp-android-pg1',
            packageId: 'ru.mast.otp',
            distributions: [
              { 
                id: 'otp-android-d1', 
                name: 'dev_CI0004001.apk', 
                version: 'v2.0.0', 
                build: 'build 400', 
                packageName: 'ru.mast.otp',
                fileSha: '046be48756e87c28cc5fb39eb59f6b2e4c0b81c60f4ca2fcad766452d78b51a1',
                severity: { crit: 0, high: 1, med: 1, low: 2 } 
              },
              { 
                id: 'otp-android-d2', 
                name: 'ift_CI0004002.apk', 
                version: 'v2.1.0', 
                build: 'build 410', 
                packageName: 'ru.mast.otp',
                nexusUrl: 'nexus.mycompany.com/CI00389965/CI00706637/D-26.001.17',
                nexusSha: 'b5f6c3f31d80ec008a67e3ecf4535ac0f2644fa7b039f3e63cb4b2cec85d7f2d',
                fileSha: 'f672aecae369570c60f29aacd94dd4119ae1c16a31bd2ee32ae65c7cd455ceb9',
                severity: { crit: 0, high: 0, med: 2, low: 4 } 
              },
              { 
                id: 'otp-android-d3', 
                name: 'psi_CI0004003.apk', 
                version: 'v2.2.0', 
                build: 'build 420', 
                packageName: 'ru.mast.otp',
                nexusUrl: 'nexus.mycompany.com/CI00372282/CI00181880/D-26.001.85',
                nexusSha: '697380a505ecca18ae5343af6657c4dcc49cecc44abfa67161fa28532582c71c',
                fileSha: '849fa424b6188139499994352e49155eaa0cb265f09d2d76395b6092cdeb64a6',
                severity: { crit: 0, high: 1, med: 1, low: 3 } 
              },
              { 
                id: 'otp-android-d4', 
                name: 'prod_CI0004004.apk', 
                version: 'v2.3.0', 
                build: 'build 430', 
                packageName: 'ru.mast.otp',
                nexusUrl: 'nexus.mycompany.com/CI00290237/CI00248427/D-26.001.66',
                nexusSha: 'a270c96d2cabab507cf39d08de0330f6de6f5025c1345a75405c30bb03f68545',
                fileSha: 'be645406a52f64405da2c9989df20930ba7113be2774afdf3a3d53a3826a9ee2',
                severity: { crit: 0, high: 0, med: 1, low: 2 } 
              },
            ],
          },
        ],
      },
    ],
  },
];

interface HierarchyPanelProps {
  selectedItem: {
    id: string;
    type: 'product' | 'project' | 'distribution';
    name: string;
  };
  onItemSelect: (item: { id: string; type: 'product' | 'project' | 'distribution'; name: string }) => void;
}

export function HierarchyPanel({ selectedItem, onItemSelect }: HierarchyPanelProps) {
  const [expandedProducts, setExpandedProducts] = useState<Set<string>>(
    new Set(['drug', 'otp'])
  );
  const [expandedProjects, setExpandedProjects] = useState<Set<string>>(
    new Set(['drug-android'])
  );
  const [expandedPackageGroups, setExpandedPackageGroups] = useState<Set<string>>(
    new Set(['drug-android-pg1'])
  );
  const [searchQuery, setSearchQuery] = useState('');

  const toggleProduct = (productId: string) => {
    const newExpanded = new Set(expandedProducts);
    if (newExpanded.has(productId)) {
      newExpanded.delete(productId);
    } else {
      newExpanded.add(productId);
    }
    setExpandedProducts(newExpanded);
  };

  const toggleProject = (projectId: string) => {
    const newExpanded = new Set(expandedProjects);
    if (newExpanded.has(projectId)) {
      newExpanded.delete(projectId);
    } else {
      newExpanded.add(projectId);
    }
    setExpandedProjects(newExpanded);
  };

  const togglePackageGroup = (packageGroupId: string) => {
    const newExpanded = new Set(expandedPackageGroups);
    if (newExpanded.has(packageGroupId)) {
      newExpanded.delete(packageGroupId);
    } else {
      newExpanded.add(packageGroupId);
    }
    setExpandedPackageGroups(newExpanded);
  };

  // Search logic: check if distribution matches search query
  const distributionMatchesSearch = (dist: Distribution): boolean => {
    if (!searchQuery.trim()) return true; // Show all when no search
    
    const query = searchQuery.toLowerCase();
    const nameWithoutExt = dist.name.replace(/\.(ipa|apk)$/, '');
    
    return (
      dist.name.toLowerCase().includes(query) ||
      nameWithoutExt.toLowerCase().includes(query) ||
      dist.version.toLowerCase().includes(query) ||
      dist.fileSha.toLowerCase().includes(query) ||
      (dist.nexusUrl && dist.nexusUrl.toLowerCase().includes(query)) ||
      (dist.nexusSha && dist.nexusSha.toLowerCase().includes(query))
    );
  };

  // Check if product/project/packageGroup contains matching distributions
  const productHasMatch = (product: Product): boolean => {
    if (!searchQuery.trim()) return true;
    
    return product.projects.some(project =>
      project.packageGroups.some(group =>
        group.distributions.some(distributionMatchesSearch)
      )
    );
  };

  const projectHasMatch = (product: Product, project: Project): boolean => {
    if (!searchQuery.trim()) return true;
    
    return project.packageGroups.some(group =>
      group.distributions.some(distributionMatchesSearch)
    );
  };

  const packageGroupHasMatch = (product: Product, project: Project, group: PackageGroup): boolean => {
    if (!searchQuery.trim()) return true;
    
    return group.distributions.some(distributionMatchesSearch);
  };

  // Auto-expand when searching
  const getAutoExpandedItems = () => {
    if (!searchQuery.trim()) return { products: new Set<string>(), projects: new Set<string>(), groups: new Set<string>() };
    
    const autoProducts = new Set<string>();
    const autoProjects = new Set<string>();
    const autoGroups = new Set<string>();
    
    products.forEach(product => {
      if (productHasMatch(product)) {
        autoProducts.add(product.id);
        
        product.projects.forEach(project => {
          if (projectHasMatch(product, project)) {
            autoProjects.add(project.id);
            
            project.packageGroups.forEach(group => {
              if (packageGroupHasMatch(product, project, group)) {
                autoGroups.add(group.id);
              }
            });
          }
        });
      }
    });
    
    return { products: autoProducts, projects: autoProjects, groups: autoGroups };
  };

  const autoExpanded = getAutoExpandedItems();
  const effectiveExpandedProducts = searchQuery.trim() ? autoExpanded.products : expandedProducts;
  const effectiveExpandedProjects = searchQuery.trim() ? autoExpanded.projects : expandedProjects;
  const effectiveExpandedPackageGroups = searchQuery.trim() ? autoExpanded.groups : expandedPackageGroups;

  return (
    <div className="w-[360px] h-screen bg-card border-r border-border flex flex-col">
      {/* Header */}
      <div className="px-4 pt-4 pb-3 border-b border-border">
        <h2 className="font-semibold text-xl mb-3">Продукты</h2>
        
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Поиск по продуктам и проектам..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8 h-8 bg-muted/30 border-border text-sm rounded-[14px]"
          />
        </div>
      </div>

      {/* Product List */}
      <div className="flex-1 overflow-y-auto custom-scrollbar px-2 py-2 space-y-0.5">
        {products.filter(product => productHasMatch(product)).map((product) => (
          <div key={product.id} className="space-y-0.5">
            {/* Product Row */}
            <button
              onClick={(e) => {
                // Stop propagation to prevent double-trigger
                e.stopPropagation();
                onItemSelect({ id: product.id, type: 'product', name: product.name });
                toggleProduct(product.id);
              }}
              className={`w-full flex items-center gap-2 pl-4 pr-2 py-1.5 rounded transition-colors text-left group ${
                selectedItem.id === product.id && selectedItem.type === 'product'
                  ? 'bg-green-600/10 dark:bg-orange-500/10 text-green-700 dark:text-orange-500 border border-green-600/20 dark:border-orange-500/20'
                  : 'hover:bg-accent/40'
              }`}
            >
              {effectiveExpandedProducts.has(product.id) ? (
                <ChevronDown className="w-4 h-4 text-green-600 dark:text-orange-500 hover:text-green-700 dark:hover:text-orange-600 flex-shrink-0 transition-colors" />
              ) : (
                <ChevronRight className="w-4 h-4 text-green-600 dark:text-orange-500 hover:text-green-700 dark:hover:text-orange-600 flex-shrink-0 transition-colors" />
              )}
              <span className="flex-1 font-semibold text-foreground text-sm">{product.name}</span>
              <Badge variant="secondary" className="text-[11px] px-1.5 py-0 h-4 leading-none">
                {product.projects.length}
              </Badge>
            </button>

            {/* Projects */}
            {effectiveExpandedProducts.has(product.id) && (
              <div className="space-y-0.5">
                {product.projects.filter(project => projectHasMatch(product, project)).map((project) => (
                  <div key={project.id} className="space-y-0.5">
                    {/* Project Row */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onItemSelect({ id: project.id, type: 'project', name: project.name });
                        toggleProject(project.id);
                      }}
                      className={`w-full flex items-center gap-2 pl-8 pr-2 py-1.5 rounded transition-colors text-left ${
                        selectedItem.id === project.id && selectedItem.type === 'project'
                          ? 'bg-green-600/10 dark:bg-orange-500/10 text-green-700 dark:text-orange-500 border border-green-600/20 dark:border-orange-500/20'
                          : 'hover:bg-accent/40'
                      }`}
                    >
                      {effectiveExpandedProjects.has(project.id) ? (
                        <ChevronDown className="w-4 h-4 text-green-600 dark:text-orange-500 hover:text-green-700 dark:hover:text-orange-600 flex-shrink-0 transition-colors" />
                      ) : (
                        <ChevronRight className="w-4 h-4 text-green-600 dark:text-orange-500 hover:text-green-700 dark:hover:text-orange-600 flex-shrink-0 transition-colors" />
                      )}
                      <span className="flex-1 text-sm font-normal text-foreground">
                        {project.name}
                      </span>
                      <Badge variant="secondary" className="text-[11px] px-1.5 py-0 h-4 leading-none">
                        {project.packageGroups.reduce((total, group) => total + group.distributions.length, 0)}
                      </Badge>
                    </button>

                    {/* Package Groups */}
                    {effectiveExpandedProjects.has(project.id) && (
                      <div className="space-y-0.5">
                        {project.packageGroups.filter(group => packageGroupHasMatch(product, project, group)).map((group) => (
                          <div key={group.id} className="space-y-0.5">
                            {/* Package Group Row */}
                            <button
                              onClick={() => togglePackageGroup(group.id)}
                              className="w-full flex items-center gap-2 pl-12 pr-2 py-1.5 rounded hover:bg-accent/40 transition-colors text-left"
                            >
                              {effectiveExpandedPackageGroups.has(group.id) ? (
                                <ChevronDown className="w-4 h-4 text-green-600 dark:text-orange-500 hover:text-green-700 dark:hover:text-orange-600 flex-shrink-0 transition-colors" />
                              ) : (
                                <ChevronRight className="w-4 h-4 text-green-600 dark:text-orange-500 hover:text-green-700 dark:hover:text-orange-600 flex-shrink-0 transition-colors" />
                              )}
                              <span className="flex-1 text-sm font-normal text-foreground">
                                {group.packageId}
                              </span>
                              <Badge variant="secondary" className="text-[11px] px-1.5 py-0 h-4 leading-none">
                                {group.distributions.length}
                              </Badge>
                            </button>

                            {/* Distributions */}
                            {effectiveExpandedPackageGroups.has(group.id) && (
                              <div className="space-y-0.5">
                                {group.distributions.filter(distributionMatchesSearch).map((distribution) => {
                                  return (
                                    <button
                                      key={distribution.id}
                                      onClick={() => onItemSelect({ id: distribution.id, type: 'distribution', name: distribution.name })}
                                      className={`w-full flex items-center justify-between gap-2 pl-20 pr-2 py-1.5 rounded transition-colors text-left ${
                                        selectedItem.id === distribution.id && selectedItem.type === 'distribution'
                                          ? 'bg-green-600/10 dark:bg-orange-500/10 text-green-700 dark:text-orange-500 border border-green-600/20 dark:border-orange-500/20'
                                          : 'hover:bg-accent/40 text-foreground'
                                      }`}
                                    >
                                      <span className="text-sm font-normal flex-shrink-0">
                                        {distribution.version}
                                      </span>
                                      <div className="flex gap-1.5 items-center flex-shrink-0">
                                        {distribution.severity.crit > 0 && (
                                          <span className="text-[11px] font-mono text-red-500">
                                            К:{distribution.severity.crit}
                                          </span>
                                        )}
                                        {distribution.severity.high > 0 && (
                                          <span className="text-[11px] font-mono text-orange-500">
                                            В:{distribution.severity.high}
                                          </span>
                                        )}
                                        {distribution.severity.med > 0 && (
                                          <span className="text-[11px] font-mono text-yellow-600">
                                            С:{distribution.severity.med}
                                          </span>
                                        )}
                                        {distribution.severity.low > 0 && (
                                          <span className="text-[11px] font-mono text-blue-500">
                                            Н:{distribution.severity.low}
                                          </span>
                                        )}
                                      </div>
                                    </button>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}