import { useState } from 'react';
import { Check, X, Copy } from 'lucide-react';
import { CopyButton } from './CopyButton';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface ContentAreaProps {
  selectedItem: {
    id: string;
    type: 'product' | 'project' | 'distribution';
    name: string;
  };
}

// Product data
export const productData: Record<string, {
  name: string;
  owner: string;
  businessBlock: string;
  ke: string;
}> = {
  'drug': {
    name: 'Друг',
    owner: 'Иванов Иван Иванович',
    businessBlock: 'Розничный бизнес',
    ke: 'CI0012345',
  },
  'otp': {
    name: 'OTP',
    owner: 'Петров Петр Петрович',
    businessBlock: 'Корпоративный бизнес',
    ke: 'CI0067890',
  },
};

// Project data
export const projectData: Record<string, {
  name: string;
  owner: string;
  ke: string;
  platform: 'iOS' | 'Android';
  packageIds: string[];
  riskCategory: string;
}> = {
  'drug-ios': {
    name: 'Друг iOS',
    owner: 'Сидоров Сидор Сидорович',
    ke: 'CI0023456',
    platform: 'iOS',
    packageIds: ['ru.mast.drug.dev', 'ru.mast.drug.ift', 'ru.mast.drug.psi', 'ru.mast.drug.prod'],
    riskCategory: 'A2',
  },
  'drug-android': {
    name: 'Друг Android',
    owner: 'Сидоров Сидор Сидорович',
    ke: 'CI0034567',
    platform: 'Android',
    packageIds: ['ru.mast.drug.dev', 'ru.mast.drug.ift', 'ru.mast.drug.psi', 'ru.mast.drug.prod'],
    riskCategory: 'A3',
  },
  'otp-ios': {
    name: 'OTP iOS',
    owner: 'Козлов Козел Козлович',
    ke: 'CI0078901',
    platform: 'iOS',
    packageIds: ['ru.mast.otp.ios'],
    riskCategory: 'A2',
  },
  'otp-android': {
    name: 'OTP Android',
    owner: 'Козлов Козел Козлович',
    ke: 'CI0089012',
    platform: 'Android',
    packageIds: ['ru.mast.otp'],
    riskCategory: 'B1',
  },
};

export const distributionData: Record<string, any> = {
  // Друг iOS
  'drug-ios-d1': {
    name: 'dev_CI0001001.ipa',
    version: 'v1.0.0',
    bundleId: 'ru.mast.drug.dev',
    platform: 'iOS',
    project: 'Друг iOS',
    environment: 'dev',
    fileType: 'ipa',
    uploadDate: '2026-01-15 10:22',
    source: 'UI',
    fileSha: 'fbb357e63638dc91cc7bb2e8aba0d6b0e9e7e7b8522f49288a354b532d6e307a',
    severity: { crit: 0, high: 0, med: 1, low: 2 },
    analysisSteps: [
      { name: 'Статический анализ', status: 'completed' },
      { name: 'Анализ загрязнения данных', status: 'completed' },
      { name: 'Компонентный анализ', status: 'not-executed' },
      { name: 'Динамический анализ', status: 'not-executed' },
    ],
    reports: [
      {
        id: 'R1',
        date: '2026-01-15 11:00',
        status: 'Готов',
        severities: { crit: 0, high: 0, med: 1, low: 2 },
      },
    ],
  },
  'drug-ios-d2': {
    name: 'ift_CI0001002.ipa',
    version: 'v1.1.0',
    bundleId: 'ru.mast.drug.ift',
    platform: 'iOS',
    project: 'Друг iOS',
    environment: 'ift',
    fileType: 'ipa',
    uploadDate: '2026-01-18 14:30',
    source: 'Nexus',
    nexusUrl: 'nexus.mycompany.com/CI00634192/CI00515198/D-26.001.64',
    nexusSha: '7e56a5f300e0763e94a2d9eba6517523e9bae3ef4657c5de11b696d13643e6fb',
    fileSha: '9b0ad768e93778f8fdcca1bba2dae536ab65efa36bac7a3899a731ea31d57dfb',
    severity: { crit: 0, high: 1, med: 1, low: 3 },
    analysisSteps: [
      { name: 'Статический анализ', status: 'completed' },
      { name: 'Анализ загрязнения данных', status: 'completed' },
      { name: 'Компонентный анализ', status: 'not-executed' },
      { name: 'Динамический анализ', status: 'not-executed' },
    ],
    reports: [
      {
        id: 'R1',
        date: '2026-01-18 15:30',
        status: 'Готов',
        severities: { crit: 0, high: 1, med: 1, low: 3 },
      },
    ],
  },
  'drug-ios-d3': {
    name: 'psi_CI0001003.ipa',
    version: 'v1.2.0',
    bundleId: 'ru.mast.drug.psi',
    platform: 'iOS',
    project: 'Друг iOS',
    environment: 'psi',
    fileType: 'ipa',
    uploadDate: '2026-01-20 09:15',
    source: 'Nexus',
    nexusUrl: 'nexus.mycompany.com/CI00299096/CI00557333/D-26.001.35',
    nexusSha: '576cef2086138d79f4230a2753aeccd3edb1a402cf7d391d1ef8e87bd973a50d',
    fileSha: '45883eb1e0fb5e3f8176f775393a2bc63f54b27f46b5e8b2e1afc8f6c438e724',
    severity: { crit: 0, high: 0, med: 2, low: 4 },
    analysisSteps: [
      { name: 'Статический анализ', status: 'completed' },
      { name: 'Анализ загрязнения данных', status: 'completed' },
      { name: 'Компонентный анализ', status: 'not-executed' },
      { name: 'Динамический анализ', status: 'not-executed' },
    ],
    reports: [
      {
        id: 'R1',
        date: '2026-01-20 10:00',
        status: 'Готов',
        severities: { crit: 0, high: 0, med: 2, low: 4 },
      },
    ],
  },
  'drug-ios-d4': {
    name: 'prod_CI0001004.ipa',
    version: 'v1.3.0',
    bundleId: 'ru.mast.drug.prod',
    platform: 'iOS',
    project: 'Друг iOS',
    environment: 'prod',
    fileType: 'ipa',
    uploadDate: '2026-01-23 16:45',
    source: 'Nexus',
    nexusUrl: 'nexus.mycompany.com/CI00380263/CI00713883/D-26.001.72',
    nexusSha: 'c0e0c497d616700c89831bf02212403f6818030344a6276ec5fd163017c7d70b',
    fileSha: 'eb56e12001fbd9ed706e55449089566b854312c33752a18e48dad8d1334fcf1f',
    severity: { crit: 0, high: 0, med: 1, low: 2 },
    analysisSteps: [
      { name: 'Статический анализ', status: 'completed' },
      { name: 'Анализ загрязнения данных', status: 'error' },
      { name: 'Компонентный анализ', status: 'not-executed' },
      { name: 'Динамический анализ', status: 'not-executed' },
    ],
    reports: [
      {
        id: 'R1',
        date: '2026-01-23 17:30',
        status: 'Готов',
        severities: { crit: 0, high: 0, med: 1, low: 2 },
      },
    ],
  },
  // Друг Android
  'drug-android-d1': {
    name: 'dev_CI0002001.apk',
    version: 'v1.0.0',
    packageName: 'ru.mast.drug.dev',
    platform: 'Android',
    project: 'Друг Android',
    environment: 'dev',
    fileType: 'apk',
    uploadDate: '2026-01-15 10:22',
    source: 'UI',
    fileSha: '8c7ae49cc3abdbcc979e435bc0cf56554be967b1ccaf4b843bf9c01df88ad443',
    severity: { crit: 1, high: 2, med: 1, low: 3 },
    analysisSteps: [
      { name: 'Статический анализ', status: 'completed' },
      { name: 'Анализ загрязнения данных', status: 'completed' },
      { name: 'Компонентный анализ', status: 'in-progress' },
      { name: 'Динамический анализ', status: 'pending' },
    ],
    reports: [
      {
        id: 'B1',
        date: '2026-01-15 11:45',
        status: 'Готов',
        severities: { crit: 1, high: 2, med: 1, low: 3 },
      },
      {
        id: 'B2',
        date: '2026-01-16 08:30',
        status: 'Готов',
        severities: { crit: 0, high: 1, med: 2, low: 4 },
      },
    ],
  },
  'drug-android-d2': {
    name: 'ift_CI0002002.apk',
    version: 'v1.1.0',
    packageName: 'ru.mast.drug.ift',
    platform: 'Android',
    project: 'Друг Android',
    environment: 'ift',
    fileType: 'apk',
    uploadDate: '2026-01-21 15:40',
    source: 'Nexus',
    nexusUrl: 'nexus.mycompany.com/CI00913912/CI00327473/D-26.001.97',
    nexusSha: 'afeb8b6dc1c94ecb28cfd099bd6dc53d8a0d4ae393eae771a61350a17a1e8f37',
    fileSha: 'd4ca5219e1c1c85c5c0908903664b3b5021673b24652274dfabc8d38538dcda3',
    severity: { crit: 0, high: 1, med: 2, low: 5 },
    analysisSteps: [
      { name: 'Статический анализ', status: 'completed' },
      { name: 'Анализ загрязнения данных', status: 'completed' },
      { name: 'Компонентный анализ', status: 'in-progress' },
      { name: 'Динамический анализ', status: 'pending' },
    ],
    reports: [
      {
        id: 'A1',
        date: '2026-01-21 16:30',
        status: 'Готов',
        severities: { crit: 0, high: 1, med: 2, low: 5 },
      },
      {
        id: 'A2',
        date: '2026-01-22 09:15',
        status: 'Частично',
        severities: { crit: 0, high: 0, med: 1, low: 3 },
      },
      {
        id: 'A3',
        date: '2026-01-22 14:20',
        status: 'Ошибка',
        severities: { crit: 0, high: 0, med: 0, low: 0 },
      },
    ],
  },
  'drug-android-d3': {
    name: 'psi_CI0002003.apk',
    version: 'v1.2.0',
    packageName: 'ru.mast.drug.psi',
    platform: 'Android',
    project: 'Друг Android',
    environment: 'psi',
    fileType: 'apk',
    uploadDate: '2026-01-20 12:00',
    source: 'Nexus',
    nexusUrl: 'nexus.mycompany.com/CI00196799/CI00119662/D-26.001.66',
    nexusSha: '12b648fec6d3523edb5283de052141b3111ea1b204cd2416957b323b4978f1b4',
    fileSha: 'b820707dc58e90b15f3e703ee1db4f1a6d08da352f481db90f57e2e436172a56',
    severity: { crit: 0, high: 0, med: 1, low: 2 },
    analysisSteps: [
      { name: 'Статический анализ', status: 'completed' },
      { name: 'Анализ загрязнения данных', status: 'completed' },
      { name: 'Компонентный анализ', status: 'error' },
      { name: 'Динамический анализ', status: 'not-executed' },
    ],
    reports: [
      {
        id: 'R1',
        date: '2026-01-20 13:00',
        status: 'Готов',
        severities: { crit: 0, high: 0, med: 1, low: 2 },
      },
    ],
  },
  'drug-android-d4': {
    name: 'prod_CI0002004.apk',
    version: 'v1.3.0',
    packageName: 'ru.mast.drug.prod',
    platform: 'Android',
    project: 'Друг Android',
    environment: 'prod',
    fileType: 'apk',
    uploadDate: '2026-01-23 14:15',
    source: 'Nexus',
    nexusUrl: 'nexus.mycompany.com/CI00242465/CI00487325/D-26.001.62',
    nexusSha: 'fe8bca1ed8f96a06b0ce78be3145233a477df7aa04e7a677c3266aebe3d34f2c',
    fileSha: 'afb6e6727b05961956663cf254f785ad1a4d690fe5e0a80a75cad0b26ffce5c0',
    severity: { crit: 0, high: 0, med: 1, low: 2 },
    analysisSteps: [
      { name: 'Статический анализ', status: 'completed' },
      { name: 'Анализ загрязнения данных', status: 'completed' },
      { name: 'Компонентный анализ', status: 'in-progress' },
      { name: 'Динамический анализ', status: 'pending' },
    ],
    reports: [
      {
        id: 'R1',
        date: '2026-01-23 15:00',
        status: 'Готов',
        severities: { crit: 0, high: 0, med: 1, low: 2 },
      },
    ],
  },
  // OTP iOS
  'otp-ios-d1': {
    name: 'dev_CI0003001.ipa',
    version: 'v2.0.0',
    bundleId: 'ru.mast.otp.ios',
    platform: 'iOS',
    project: 'OTP iOS',
    environment: 'dev',
    fileType: 'ipa',
    uploadDate: '2026-01-16 11:20',
    source: 'UI',
    fileSha: '37caa31021c9c984cbcffbe17a8b95868791a05d8db925bf74b44df89acb46d4',
    severity: { crit: 0, high: 0, med: 1, low: 1 },
    analysisSteps: [
      { name: 'Статический анализ', status: 'completed' },
      { name: 'Анализ загрязнения данных', status: 'completed' },
      { name: 'Компонентный анализ', status: 'in-progress' },
      { name: 'Динамический анализ', status: 'pending' },
    ],
    reports: [
      {
        id: 'R1',
        date: '2026-01-16 12:15',
        status: 'Готов',
        severities: { crit: 0, high: 0, med: 1, low: 1 },
      },
    ],
  },
  'otp-ios-d2': {
    name: 'ift_CI0003002.ipa',
    version: 'v2.1.0',
    bundleId: 'ru.mast.otp.ios',
    platform: 'iOS',
    project: 'OTP iOS',
    environment: 'ift',
    fileType: 'ipa',
    uploadDate: '2026-01-19 13:50',
    source: 'Nexus',
    nexusUrl: 'nexus.mycompany.com/CI00718772/CI00490840/D-26.001.16',
    nexusSha: '9160d876b54f8e15370b398f1f3505994156f7c9566f0a6fb1b639998ee6d254',
    fileSha: 'bf5094dddfd83ca3c34c671cc19b9e28f9cae40114f4e2f6733f7619e85889ea',
    severity: { crit: 0, high: 1, med: 0, low: 2 },
    analysisSteps: [
      { name: 'Статический анализ', status: 'completed' },
      { name: 'Анализ загрязнения данных', status: 'completed' },
      { name: 'Компонентный анализ', status: 'not-executed' },
      { name: 'Динамический анализ', status: 'error' },
    ],
    reports: [
      {
        id: 'R1',
        date: '2026-01-19 14:45',
        status: 'Готов',
        severities: { crit: 0, high: 1, med: 0, low: 2 },
      },
    ],
  },
  'otp-ios-d3': {
    name: 'psi_CI0003003.ipa',
    version: 'v2.2.0',
    bundleId: 'ru.mast.otp.ios',
    platform: 'iOS',
    project: 'OTP iOS',
    environment: 'psi',
    fileType: 'ipa',
    uploadDate: '2026-01-22 10:30',
    source: 'Nexus',
    nexusUrl: 'nexus.mycompany.com/CI00756364/CI00341149/D-26.001.18',
    nexusSha: 'f2516b1854f4435dc4774ac0b67b0ff1138b7ff272cf8143c66970b874026366',
    fileSha: '5f07213b5ee285bf566f762f229a60e6a08c89d8e91af3ae0626e379c34091cd',
    severity: { crit: 0, high: 0, med: 2, low: 3 },
    analysisSteps: [
      { name: 'Статический анализ', status: 'completed' },
      { name: 'Анализ загрязнения данных', status: 'completed' },
      { name: 'Компонентный анализ', status: 'in-progress' },
      { name: 'Динамический анализ', status: 'pending' },
    ],
    reports: [
      {
        id: 'R1',
        date: '2026-01-22 11:20',
        status: 'Готов',
        severities: { crit: 0, high: 0, med: 2, low: 3 },
      },
    ],
  },
  'otp-ios-d4': {
    name: 'prod_CI0003004.ipa',
    version: 'v2.3.0',
    bundleId: 'ru.mast.otp.ios',
    platform: 'iOS',
    project: 'OTP iOS',
    environment: 'prod',
    fileType: 'ipa',
    uploadDate: '2026-01-24 15:25',
    source: 'Nexus',
    nexusUrl: 'nexus.mycompany.com/CI00352852/CI00590646/D-26.001.06',
    nexusSha: '598d76ba87eee3a851f28188e3831a0d3126d3fd41773c0b3a11d7d87ac121db',
    fileSha: 'e464c486b6b112c27adbc2559d6a8e6b75d58bf084dca7d74267c543aa0b3572',
    severity: { crit: 0, high: 0, med: 1, low: 2 },
    analysisSteps: [
      { name: 'Статический анализ', status: 'completed' },
      { name: 'Анализ загрязнения данных', status: 'completed' },
      { name: 'Компонентный анализ', status: 'in-progress' },
      { name: 'Динамический анализ', status: 'pending' },
    ],
    reports: [
      {
        id: 'R1',
        date: '2026-01-24 16:15',
        status: 'Готов',
        severities: { crit: 0, high: 0, med: 1, low: 2 },
      },
    ],
  },
  // OTP Android
  'otp-android-d1': {
    name: 'dev_CI0004001.apk',
    version: 'v2.0.0',
    packageName: 'ru.mast.otp',
    platform: 'Android',
    project: 'OTP Android',
    environment: 'dev',
    fileType: 'apk',
    uploadDate: '2026-01-16 09:45',
    source: 'UI',
    fileSha: '046be48756e87c28cc5fb39eb59f6b2e4c0b81c60f4ca2fcad766452d78b51a1',
    severity: { crit: 0, high: 1, med: 1, low: 2 },
    analysisSteps: [
      { name: 'Статический анализ', status: 'completed' },
      { name: 'Анализ загрязнения данных', status: 'completed' },
      { name: 'Компонентный анализ', status: 'in-progress' },
      { name: 'Динамический анализ', status: 'pending' },
    ],
    reports: [
      {
        id: 'R1',
        date: '2026-01-16 10:30',
        status: 'Готов',
        severities: { crit: 0, high: 1, med: 1, low: 2 },
      },
    ],
  },
  'otp-android-d2': {
    name: 'ift_CI0004002.apk',
    version: 'v2.1.0',
    packageName: 'ru.mast.otp',
    platform: 'Android',
    project: 'OTP Android',
    environment: 'ift',
    fileType: 'apk',
    uploadDate: '2026-01-19 16:20',
    source: 'Nexus',
    nexusUrl: 'nexus.mycompany.com/CI00389965/CI00706637/D-26.001.17',
    nexusSha: 'b5f6c3f31d80ec008a67e3ecf4535ac0f2644fa7b039f3e63cb4b2cec85d7f2d',
    fileSha: 'f672aecae369570c60f29aacd94dd4119ae1c16a31bd2ee32ae65c7cd455ceb9',
    severity: { crit: 0, high: 0, med: 2, low: 4 },
    analysisSteps: [
      { name: 'Статический анализ', status: 'completed' },
      { name: 'Анализ загрязнения данных', status: 'completed' },
      { name: 'Компонентный анализ', status: 'in-progress' },
      { name: 'Динамический анализ', status: 'pending' },
    ],
    reports: [
      {
        id: 'R1',
        date: '2026-01-19 17:10',
        status: 'Готов',
        severities: { crit: 0, high: 0, med: 2, low: 4 },
      },
    ],
  },
  'otp-android-d3': {
    name: 'psi_CI0004003.apk',
    version: 'v2.2.0',
    packageName: 'ru.mast.otp',
    platform: 'Android',
    project: 'OTP Android',
    environment: 'psi',
    fileType: 'apk',
    uploadDate: '2026-01-22 11:55',
    source: 'Nexus',
    nexusUrl: 'nexus.mycompany.com/CI00372282/CI00181880/D-26.001.85',
    nexusSha: '697380a505ecca18ae5343af6657c4dcc49cecc44abfa67161fa28532582c71c',
    fileSha: '849fa424b6188139499994352e49155eaa0cb265f09d2d76395b6092cdeb64a6',
    severity: { crit: 0, high: 1, med: 1, low: 3 },
    analysisSteps: [
      { name: 'Статический анализ', status: 'completed' },
      { name: 'Анализ загрязнения данных', status: 'completed' },
      { name: 'Компонентный анализ', status: 'in-progress' },
      { name: 'Динамический анализ', status: 'pending' },
    ],
    reports: [
      {
        id: 'R1',
        date: '2026-01-22 12:45',
        status: 'Готов',
        severities: { crit: 0, high: 1, med: 1, low: 3 },
      },
    ],
  },
  'otp-android-d4': {
    name: 'prod_CI0004004.apk',
    version: 'v2.3.0',
    packageName: 'ru.mast.otp',
    platform: 'Android',
    project: 'OTP Android',
    environment: 'prod',
    fileType: 'apk',
    uploadDate: '2026-01-24 14:10',
    source: 'Nexus',
    nexusUrl: 'nexus.mycompany.com/CI00290237/CI00248427/D-26.001.66',
    nexusSha: 'a270c96d2cabab507cf39d08de0330f6de6f5025c1345a75405c30bb03f68545',
    fileSha: 'be645406a52f64405da2c9989df20930ba7113be2774afdf3a3d53a3826a9ee2',
    severity: { crit: 0, high: 0, med: 1, low: 2 },
    analysisSteps: [
      { name: 'Статический анализ', status: 'error' },
      { name: 'Анализ загрязнения данных', status: 'completed' },
      { name: 'Компонентный анализ', status: 'not-executed' },
      { name: 'Динамический анализ', status: 'not-executed' },
    ],
    reports: [
      {
        id: 'R1',
        date: '2026-01-24 15:00',
        status: 'Готов',
        severities: { crit: 0, high: 0, med: 1, low: 2 },
      },
    ],
  },
};

export function ContentArea({ selectedItem }: ContentAreaProps) {
  const [activeTab, setActiveTab] = useState('info');
  
  // Helper function to get all reports for a product
  const getProductReports = (productId: string) => {
    const reports: any[] = [];
    Object.entries(distributionData).forEach(([distId, dist]) => {
      // Check if distribution belongs to this product
      if (
        (productId === 'drug' && (dist.project === 'Друг iOS' || dist.project === 'Друг Android')) ||
        (productId === 'otp' && (dist.project === 'OTP iOS' || dist.project === 'OTP Android'))
      ) {
        dist.reports.forEach((report: any) => {
          reports.push({
            ...report,
            distributionName: dist.name,
            distributionId: distId,
            project: dist.project,
            version: dist.version,
            uploadDate: dist.uploadDate,
          });
        });
      }
    });
    // Sort by date descending
    return reports.sort((a, b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime());
  };

  // Helper function to get all reports for a project
  const getProjectReports = (projectId: string) => {
    const reports: any[] = [];
    const projectMap: Record<string, string> = {
      'drug-ios': 'Друг iOS',
      'drug-android': 'Друг Android',
      'otp-ios': 'OTP iOS',
      'otp-android': 'OTP Android',
    };
    const projectName = projectMap[projectId];
    
    Object.entries(distributionData).forEach(([distId, dist]) => {
      if (dist.project === projectName) {
        dist.reports.forEach((report: any) => {
          reports.push({
            ...report,
            distributionName: dist.name,
            distributionId: distId,
            version: dist.version,
            uploadDate: dist.uploadDate,
          });
        });
      }
    });
    // Sort by date descending
    return reports.sort((a, b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime());
  };
  
  // Handle product and project views
  if (selectedItem.type === 'product' || selectedItem.type === 'project') {
    const product = selectedItem.type === 'product' ? productData[selectedItem.id] : null;
    const project = selectedItem.type === 'project' ? projectData[selectedItem.id] : null;
    const reports = selectedItem.type === 'product' 
      ? getProductReports(selectedItem.id)
      : getProjectReports(selectedItem.id);
    
    return (
      <div className="flex-1 h-screen overflow-y-auto custom-scrollbar bg-background">
        <div className="w-full mx-auto px-8 pt-4 pb-8 space-y-6">
          {/* Header */}
          <div className="space-y-4">
            {/* Title */}
            <h1 className="text-xl font-semibold text-foreground leading-tight mb-3">
              {selectedItem.name}
            </h1>
            
            {/* Meta Chips */}
            <div className="flex gap-2">
              <Badge variant="outline" className="px-3 py-1 text-sm rounded-[14px]">
                {selectedItem.type === 'product' 
                  ? `КЭ: ${product?.ke}` 
                  : `КЭ: ${project?.ke}`
                }
              </Badge>
              {selectedItem.type === 'project' && project && (
                <Badge variant="outline" className="px-3 py-1 text-sm rounded-[14px]">
                  Категория риска: {project.riskCategory}
                </Badge>
              )}
            </div>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-[400px] grid-cols-2 mx-auto">
              <TabsTrigger value="info">Информация</TabsTrigger>
              <TabsTrigger value="reports">Отчеты</TabsTrigger>
            </TabsList>

            {/* Tab 1: Информация */}
            <TabsContent value="info" className="space-y-6 mt-6">
              {/* Main Information Card */}
              {product && (
                <Card className="shadow-sm rounded-[16px] max-w-[480px]">
                  <CardHeader>
                    <CardTitle className="text-base font-semibold">Основная информация</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-1.5">
                    <div className="flex justify-between items-center py-1.5 border-b border-border">
                      <span className="text-sm text-muted-foreground">ФИО владельца</span>
                      <span className="text-sm font-normal text-foreground">{product.owner}</span>
                    </div>
                    <div className="flex justify-between items-center py-1.5 border-b border-border">
                      <span className="text-sm text-muted-foreground">Бизнес блок</span>
                      <span className="text-sm font-normal text-foreground">{product.businessBlock}</span>
                    </div>
                    <div className="flex justify-between items-center py-1.5">
                      <span className="text-sm text-muted-foreground">КЭ</span>
                      <span className="text-sm font-normal text-foreground">{product.ke}</span>
                    </div>
                  </CardContent>
                </Card>
              )}

              {project && (
                <Card className="shadow-sm rounded-[16px] max-w-[480px]">
                  <CardHeader>
                    <CardTitle className="text-base font-semibold">Основная информация</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-1.5">
                    <div className="flex justify-between items-center py-1.5 border-b border-border">
                      <span className="text-sm text-muted-foreground">ФИО владельца</span>
                      <span className="text-sm font-normal text-foreground">{project.owner}</span>
                    </div>
                    <div className="flex justify-between items-center py-1.5 border-b border-border">
                      <span className="text-sm text-muted-foreground">КЭ</span>
                      <span className="text-sm font-normal text-foreground">{project.ke}</span>
                    </div>
                    <div className="flex justify-between items-center py-1.5 border-b border-border">
                      <span className="text-sm text-muted-foreground">Платформа</span>
                      <span className="text-sm font-normal text-foreground">{project.platform}</span>
                    </div>
                    <div className="flex justify-between items-start gap-8 py-1.5">
                      <span className="text-sm text-muted-foreground flex-shrink-0">
                        {project.platform === 'iOS' ? 'Bundle ID' : 'Package name'}
                      </span>
                      <div className="flex flex-col items-end gap-1.5">
                        {project.packageIds.map((packageId, index) => (
                          <code 
                            key={index}
                            className="text-xs font-mono px-2 py-1 bg-muted/50 text-foreground rounded-md border border-border/50"
                          >
                            {packageId}
                          </code>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Tab 2: Отчеты */}
            <TabsContent value="reports" className="space-y-6 mt-6">
              <Card className="shadow-sm rounded-[16px]">
                <CardHeader>
                  <CardTitle className="text-base font-semibold">
                    {selectedItem.type === 'product' ? 'Все отчеты продукта' : 'Отчеты проекта'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {reports.length > 0 ? (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="text-sm">ID отчета</TableHead>
                          <TableHead className="text-sm">Дистрибутив</TableHead>
                          <TableHead className="text-sm">Версия</TableHead>
                          {selectedItem.type === 'product' && (
                            <TableHead className="text-sm">Проект</TableHead>
                          )}
                          <TableHead className="text-sm">Дата</TableHead>
                          <TableHead className="text-sm">Статус</TableHead>
                          <TableHead className="text-sm">Критичности</TableHead>
                          <TableHead className="text-sm">Действия</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {reports.map((report: any, index: number) => (
                          <TableRow key={index}>
                            <TableCell className="text-sm font-normal">Отчет #{report.id}</TableCell>
                            <TableCell className="text-sm font-normal">{report.distributionName}</TableCell>
                            <TableCell className="text-sm text-muted-foreground">{report.version}</TableCell>
                            {selectedItem.type === 'product' && (
                              <TableCell className="text-sm text-muted-foreground">{report.project}</TableCell>
                            )}
                            <TableCell className="text-sm text-muted-foreground">{report.date}</TableCell>
                            <TableCell>
                              <Badge
                                variant={report.status === 'Готов' ? 'default' : report.status === 'Частично' ? 'secondary' : 'outline'}
                                className={
                                  report.status === 'Готов'
                                    ? 'bg-green-600/10 dark:bg-green-500/10 text-green-700 dark:text-green-600 border-green-600/20 dark:border-green-500/20 hover:bg-green-600/20 dark:hover:bg-green-500/20 rounded-[14px]'
                                    : report.status === 'Частично'
                                    ? 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20 hover:bg-yellow-500/20 rounded-[14px]'
                                    : 'bg-red-500/10 text-red-600 border-red-500/20 hover:bg-red-500/20 rounded-[14px]'
                                }
                              >
                                {report.status}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                {report.severities.crit > 0 && (
                                  <Badge variant="outline" className="text-xs px-2 py-0.5 bg-red-500/10 text-red-500 border-red-500/20 rounded-[14px]">
                                    К:{report.severities.crit}
                                  </Badge>
                                )}
                                {report.severities.high > 0 && (
                                  <Badge variant="outline" className="text-xs px-2 py-0.5 bg-orange-500/10 text-orange-500 border-orange-500/20 rounded-[14px]">
                                    В:{report.severities.high}
                                  </Badge>
                                )}
                                {report.severities.med > 0 && (
                                  <Badge variant="outline" className="text-xs px-2 py-0.5 bg-yellow-500/10 text-yellow-600 border-yellow-500/20 rounded-[14px]">
                                    С:{report.severities.med}
                                  </Badge>
                                )}
                                {report.severities.low > 0 && (
                                  <Badge variant="outline" className="text-xs px-2 py-0.5 bg-blue-500/10 text-blue-500 border-blue-500/20 rounded-[14px]">
                                    Н:{report.severities.low}
                                  </Badge>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              <button className="text-sm text-green-600 dark:text-orange-500 hover:text-green-700 dark:hover:text-orange-600 font-normal">
                                Открыть
                              </button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : (
                    <p className="text-sm text-muted-foreground text-center py-8">
                      Отчеты не найдены
                    </p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    );
  }
  
  // Get distribution data
  const distribution = distributionData[selectedItem.id];
  
  // If no distribution found, return empty state
  if (!distribution) {
    return (
      <div className="flex-1 h-screen overflow-y-auto bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Дистрбутив не найден</p>
      </div>
    );
  }

  return (
    <div className="flex-1 h-screen overflow-y-auto custom-scrollbar bg-background">
      <div className="w-full mx-auto px-8 pt-4 pb-8 space-y-6">
        {/* Header */}
        <div className="space-y-4">
          {/* Title */}
          <h1 className="text-xl font-semibold text-foreground leading-tight mb-3">
            {distribution.name} — {distribution.version}
          </h1>
          
          {/* Meta Chips */}
          <div className="flex gap-2">
            <Badge variant="outline" className="px-3 py-1 text-sm rounded-[14px]">
              Проект: {distribution.project}
            </Badge>
            <Badge variant="outline" className="px-3 py-1 text-sm rounded-[14px]">
              Среда: {distribution.environment}
            </Badge>
            <Badge variant="outline" className="px-3 py-1 text-sm rounded-[14px]">
              Тип файла: {distribution.fileType}
            </Badge>
          </div>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-[400px] grid-cols-2 mx-auto">
            <TabsTrigger value="info">Информация</TabsTrigger>
            <TabsTrigger value="reports">Отчеты</TabsTrigger>
          </TabsList>

          {/* Tab 1: Информация */}
          <TabsContent value="info" className="space-y-6 mt-6">
            {/* 2-Column Layout: Информация / 2 колонки */}
            <div className="flex gap-6 max-w-[1200px]">
              {/* Left Column - Fixed Width */}
              <div className="flex flex-col gap-6 w-[380px] flex-shrink-0">
                {/* Сводка по критичности Card */}
                <Card className="shadow-sm rounded-[16px] w-full">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base font-semibold">Сводка по критичности</CardTitle>
                  </CardHeader>
                  <CardContent className="pb-5">
                    <div className="grid grid-cols-4 gap-4">
                      <div className="text-center space-y-2">
                        <div className="text-xs text-muted-foreground uppercase tracking-wider">Крит.</div>
                        <div className="text-2xl font-semibold text-red-500">{distribution.severity.crit}</div>
                      </div>
                      <div className="text-center space-y-2">
                        <div className="text-xs text-muted-foreground uppercase tracking-wider">Выс.</div>
                        <div className="text-2xl font-semibold text-orange-500">{distribution.severity.high}</div>
                      </div>
                      <div className="text-center space-y-2">
                        <div className="text-xs text-muted-foreground uppercase tracking-wider">Сред.</div>
                        <div className="text-2xl font-semibold text-yellow-500">{distribution.severity.med}</div>
                      </div>
                      <div className="text-center space-y-2">
                        <div className="text-xs text-muted-foreground uppercase tracking-wider">Низ.</div>
                        <div className="text-2xl font-semibold text-blue-500">{distribution.severity.low}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Статус анализа Card */}
                <Card className="shadow-sm rounded-[16px] w-full">
                  <CardHeader>
                    <CardTitle className="text-base font-semibold">Статус анализа</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {distribution.analysisSteps.map((step: any, index: number) => (
                        <div key={index} className="flex items-center gap-3">
                          {step.status === 'completed' ? (
                            <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 bg-green-500/10 text-green-500 dark:bg-orange-500/10 dark:text-orange-500">
                              <Check className="w-4 h-4" />
                            </div>
                          ) : step.status === 'error' ? (
                            <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 bg-red-500/10 text-red-500 border border-red-500/20">
                              <X className="w-3.5 h-3.5" />
                            </div>
                          ) : (
                            <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 bg-gray-100 dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
                              <div className="w-3 h-3 rounded-full border-2 border-gray-300 dark:border-gray-600" />
                            </div>
                          )}
                          <span className="text-sm font-normal text-foreground">{step.name}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Right Column - Fill Container */}
              <div className="flex flex-col flex-1">
                {/* Метаданные Card */}
                <Card className="shadow-sm rounded-[16px] w-full">
                  <CardHeader>
                    <CardTitle className="text-base font-semibold">Метаданные</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-1.5 pr-3">
                    <div className="flex justify-between items-center py-1.5 border-b border-border gap-4">
                      <span className="text-sm text-muted-foreground">Версия</span>
                      <div className="flex items-center gap-1.5 flex-1 justify-end">
                        <span className="text-sm font-normal text-foreground">{distribution.version}</span>
                        <div className="w-6 flex-shrink-0" />
                      </div>
                    </div>
                    {distribution.packageName && (
                      <div className="flex justify-between items-center py-1.5 border-b border-border gap-4">
                        <span className="text-sm text-muted-foreground">Package name</span>
                        <div className="flex items-center gap-1.5 flex-1 justify-end">
                          <span className="text-sm font-normal text-foreground font-mono text-xs">{distribution.packageName}</span>
                          <div className="w-6 flex-shrink-0" />
                        </div>
                      </div>
                    )}
                    {distribution.bundleId && (
                      <div className="flex justify-between items-center py-1.5 border-b border-border gap-4">
                        <span className="text-sm text-muted-foreground">Bundle ID</span>
                        <div className="flex items-center gap-1.5 flex-1 justify-end">
                          <span className="text-sm font-normal text-foreground font-mono text-xs">{distribution.bundleId}</span>
                          <div className="w-6 flex-shrink-0" />
                        </div>
                      </div>
                    )}
                    <div className="flex justify-between items-center py-1.5 border-b border-border gap-4">
                      <span className="text-sm text-muted-foreground">Сред</span>
                      <div className="flex items-center gap-1.5 flex-1 justify-end">
                        <span className="text-sm font-normal text-foreground">{distribution.environment}</span>
                        <div className="w-6 flex-shrink-0" />
                      </div>
                    </div>
                    <div className="flex justify-between items-center py-1.5 border-b border-border gap-4">
                      <span className="text-sm text-muted-foreground">Платформа</span>
                      <div className="flex items-center gap-1.5 flex-1 justify-end">
                        <span className="text-sm font-normal text-foreground">{distribution.fileType === 'apk' ? 'Android' : 'iOS'}</span>
                        <div className="w-6 flex-shrink-0" />
                      </div>
                    </div>
                    <div className="flex justify-between items-center py-1.5 border-b border-border gap-4">
                      <span className="text-sm text-muted-foreground">Дата загрузки</span>
                      <div className="flex items-center gap-1.5 flex-1 justify-end">
                        <span className="text-sm font-normal text-foreground">{distribution.uploadDate}</span>
                        <div className="w-6 flex-shrink-0" />
                      </div>
                    </div>
                    <div className="flex justify-between items-center py-1.5 border-b border-border gap-4">
                      <span className="text-sm text-muted-foreground">Источник</span>
                      <div className="flex items-center gap-1.5 flex-1 justify-end">
                        <span className="text-sm font-normal text-foreground">{distribution.source}</span>
                        <div className="w-6 flex-shrink-0" />
                      </div>
                    </div>
                    {distribution.nexusUrl && (
                      <div className="flex justify-between items-start py-1.5 border-b border-border gap-4">
                        <span className="text-sm text-muted-foreground flex-shrink-0">Nexus URL</span>
                        <div className="flex items-start gap-1.5 flex-1 justify-end">
                          <span className="text-sm font-normal text-foreground font-mono text-xs text-right break-all max-w-[65%]">{distribution.nexusUrl}</span>
                          <CopyButton value={distribution.nexusUrl} />
                        </div>
                      </div>
                    )}
                    {distribution.nexusSha && (
                      <div className="flex justify-between items-start py-1.5 border-b border-border gap-4">
                        <span className="text-sm text-muted-foreground flex-shrink-0">Nexus SHA</span>
                        <div className="flex items-start gap-1.5 flex-1 justify-end">
                          <span className="text-sm font-normal text-foreground font-mono text-[10px] text-right break-all max-w-[60%]">{distribution.nexusSha}</span>
                          <CopyButton value={distribution.nexusSha} />
                        </div>
                      </div>
                    )}
                    <div className="flex justify-between items-start py-1.5 gap-4">
                      <span className="text-sm text-muted-foreground flex-shrink-0">SHA файла</span>
                      <div className="flex items-start gap-1.5 flex-1 justify-end">
                        <span className="text-sm font-normal text-foreground font-mono text-[10px] text-right break-all max-w-[60%]">{distribution.fileSha}</span>
                        <CopyButton value={distribution.fileSha} />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Tab 2: Отчеты */}
          <TabsContent value="reports" className="space-y-6 mt-6">
            <Card className="shadow-sm rounded-[16px]">
              <CardHeader>
                <CardTitle className="text-base font-semibold">Отчеты по дистрибутиву</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-sm">ID отчета</TableHead>
                      <TableHead className="text-sm">Дата</TableHead>
                      <TableHead className="text-sm">Статус</TableHead>
                      <TableHead className="text-sm">Критичности</TableHead>
                      <TableHead className="text-sm">Действия</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {distribution.reports.map((report: any, index: number) => (
                      <TableRow key={index}>
                        <TableCell className="text-sm font-normal">Отчет #{report.id}</TableCell>
                        <TableCell className="text-sm text-muted-foreground">{report.date}</TableCell>
                        <TableCell>
                          <Badge
                            variant={report.status === 'Готов' ? 'default' : report.status === 'Частично' ? 'secondary' : 'outline'}
                            className={
                              report.status === 'Готов'
                                ? 'bg-green-600/10 dark:bg-green-500/10 text-green-700 dark:text-green-600 border-green-600/20 dark:border-green-500/20 hover:bg-green-600/20 dark:hover:bg-green-500/20 rounded-[14px]'
                                : report.status === 'Частично'
                                ? 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20 hover:bg-yellow-500/20 rounded-[14px]'
                                : 'bg-red-500/10 text-red-600 border-red-500/20 hover:bg-red-500/20 rounded-[14px]'
                            }
                          >
                            {report.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            {report.severities.crit > 0 && (
                              <Badge variant="outline" className="text-xs px-2 py-0.5 bg-red-500/10 text-red-500 border-red-500/20 rounded-[14px]">
                                К:{report.severities.crit}
                              </Badge>
                            )}
                            {report.severities.high > 0 && (
                              <Badge variant="outline" className="text-xs px-2 py-0.5 bg-orange-500/10 text-orange-500 border-orange-500/20 rounded-[14px]">
                                В:{report.severities.high}
                              </Badge>
                            )}
                            {report.severities.med > 0 && (
                              <Badge variant="outline" className="text-xs px-2 py-0.5 bg-yellow-500/10 text-yellow-600 border-yellow-500/20 rounded-[14px]">
                                С:{report.severities.med}
                              </Badge>
                            )}
                            {report.severities.low > 0 && (
                              <Badge variant="outline" className="text-xs px-2 py-0.5 bg-blue-500/10 text-blue-500 border-blue-500/20 rounded-[14px]">
                                Н:{report.severities.low}
                              </Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <button className="text-sm text-green-600 dark:text-orange-500 hover:text-green-700 dark:hover:text-orange-600 font-normal">
                            Открыть
                          </button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}