import { Badge } from './ui/badge';
import { Tabs, TabsList, TabsTrigger } from './ui/tabs';
import { distributionData, projectData } from './ContentArea';

// Helper function to format date to DD.MM.YYYY
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  return `${day}.${month}.${year}`;
};

// Helper function to generate random scan time (5-12 minutes)
const generateScanTime = (seed: string) => {
  // Simple hash function for consistent random values
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = ((hash << 5) - hash) + seed.charCodeAt(i);
    hash = hash & hash;
  }
  const minutes = 5 + (Math.abs(hash) % 8); // 5 to 12 minutes
  return `${minutes} мин`;
};

// Helper function to find project by project name
const findProjectByName = (projectName: string) => {
  return Object.values(projectData).find((proj: any) => proj.name === projectName);
};

interface ReportsPageProps {
  onNavigateToDistribution: (distributionId: string, distributionName: string) => void;
}

export function ReportsPage({ onNavigateToDistribution }: ReportsPageProps) {
  // Collect all reports from all distributions
  const allReports: any[] = [];
  
  Object.entries(distributionData).forEach(([distId, dist]) => {
    const project = findProjectByName(dist.project);
    
    dist.reports.forEach((report: any) => {
      allReports.push({
        reportId: report.id,
        ke: project?.ke || 'N/A',
        riskCategory: project?.riskCategory || 'N/A',
        mobileApp: dist.project,
        platform: dist.platform,
        distributionId: distId,
        distributionName: dist.name,
        version: dist.version,
        appIdentifier: dist.packageName || dist.bundleId || 'N/A',
        date: formatDate(report.date),
        scanTime: generateScanTime(distId + report.id),
        status: report.status,
        severities: report.severities,
      });
    });
  });
  
  // Sort by date descending
  allReports.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="flex-1 h-screen flex flex-col overflow-hidden">
      {/* Fixed Header */}
      <div className="px-8 pt-4 pb-4 border-b border-border shrink-0">
        <h2 className="font-semibold text-xl">Отчеты</h2>
      </div>
      
      {/* Tabs */}
      <div className="px-8 pt-4 pb-4 shrink-0">
        <Tabs defaultValue="reports" className="w-full">
          <TabsList>
            <TabsTrigger value="reports">Отчеты</TabsTrigger>
            <TabsTrigger value="statistics">Статистика</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>
      
      {/* Table Container with Horizontal and Vertical Scroll */}
      <div className="flex-1 overflow-auto custom-scrollbar">
        <div className="px-8">
          <div className="inline-block min-w-full">
            {/* Fixed Table Header */}
            <div className="sticky top-0 bg-background z-10 border-b border-border">
              <div className="flex gap-4 py-3 min-w-[1200px]">
                <div className="min-w-[120px] text-sm font-medium">ID отчета</div>
                <div className="min-w-[100px] text-sm font-medium">КЭ</div>
                <div className="min-w-[180px] text-sm font-medium">Мобильное приложение</div>
                <div className="min-w-[140px] text-sm font-medium">Версия дистрибутива</div>
                <div className="min-w-[200px] text-sm font-medium">Идентификатор МП</div>
                <div className="min-w-[100px] text-sm font-medium">Дата</div>
                <div className="min-w-[200px] text-sm font-medium">Дефекты</div>
                <div className="min-w-[100px] text-sm font-medium">Статус</div>
              </div>
            </div>
            
            {/* Scrollable Table Body */}
            <div>
              {allReports.map((report, index) => (
                <div key={index} className="flex gap-4 py-3 border-b border-border hover:bg-accent/50 transition-colors min-w-[1200px]">
                  <div className="min-w-[120px] text-sm font-normal">Отчет #{report.reportId}</div>
                  <div className="min-w-[100px] text-sm text-muted-foreground">{report.ke}</div>
                  <div className="min-w-[180px] text-sm text-muted-foreground">{report.mobileApp}</div>
                  <div className="min-w-[140px] text-sm">
                    <button
                      onClick={() => onNavigateToDistribution(report.distributionId, report.distributionName)}
                      className="text-green-600 dark:text-green-500 hover:text-green-700 dark:hover:text-green-400 hover:underline cursor-pointer transition-colors"
                    >
                      {report.version}
                    </button>
                  </div>
                  <div className="min-w-[200px] text-sm text-muted-foreground font-mono text-xs">{report.appIdentifier}</div>
                  <div className="min-w-[100px] text-sm text-muted-foreground">{report.date}</div>
                  <div className="min-w-[200px]">
                    <div className="flex gap-2 flex-wrap">
                      {report.severities.crit > 0 && (
                        <Badge variant="outline" className="text-xs px-2 py-0.5 bg-red-500/10 text-red-500 border-red-500/20 rounded-[14px]">
                          К:{report.severities.crit}
                        </Badge>
                      )}
                      {report.severities.high > 0 && (
                        <Badge variant="outline" className="text-xs px-2 py-0.5 bg-orange-500/10 text-orange-500 border-orange-500/20 rounded-[14px]">
                          В:{report.severities.high}
                        </Badge>
                      )}
                      {report.severities.med > 0 && (
                        <Badge variant="outline" className="text-xs px-2 py-0.5 bg-yellow-500/10 text-yellow-600 border-yellow-500/20 rounded-[14px]">
                          С:{report.severities.med}
                        </Badge>
                      )}
                      {report.severities.low > 0 && (
                        <Badge variant="outline" className="text-xs px-2 py-0.5 bg-blue-500/10 text-blue-500 border-blue-500/20 rounded-[14px]">
                          Н:{report.severities.low}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="min-w-[100px]">
                    <Badge
                      variant={report.status === 'Готов' ? 'default' : report.status === 'Частично' ? 'secondary' : 'outline'}
                      className={
                        report.status === 'Готов'
                          ? 'bg-green-600/10 dark:bg-green-500/10 text-green-700 dark:text-green-600 border-green-600/20 dark:border-green-500/20 hover:bg-green-600/20 dark:hover:bg-green-500/20 rounded-[14px]'
                          : report.status === 'Частично'
                          ? 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20 hover:bg-yellow-500/20 rounded-[14px]'
                          : 'bg-red-500/10 text-red-600 border-red-500/20 hover:bg-red-500/20 rounded-[14px]'
                      }
                    >
                      {report.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}