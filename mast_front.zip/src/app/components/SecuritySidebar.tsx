import { Home, ChevronsLeft, ChevronsRight, FileText } from 'lucide-react';

interface SecuritySidebarProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
  activeSection: 'home' | 'reports';
  onSectionChange: (section: 'home' | 'reports') => void;
}

export function SecuritySidebar({ collapsed, onToggleCollapse, activeSection, onSectionChange }: SecuritySidebarProps) {
  return (
    <div
      className={`h-screen bg-sidebar border-r border-sidebar-border flex flex-col transition-all duration-300 ${
        collapsed ? 'w-[72px]' : 'w-[260px]'
      }`}
    >
      {/* Top Brand Area */}
      <div className="px-6 pt-4 pb-3 border-b border-sidebar-border relative">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-green-600 to-green-700 dark:from-orange-500 dark:to-orange-600 flex items-center justify-center flex-shrink-0">
            <span className="font-semibold text-white text-sm">M</span>
          </div>
          {!collapsed && (
            <span className="font-semibold text-sidebar-foreground text-xl">MAST</span>
          )}
        </div>
        
        {/* Collapse Toggle Button */}
        <button
          onClick={onToggleCollapse}
          className="absolute -right-3 top-8 w-6 h-6 rounded-full bg-card border border-border shadow-sm flex items-center justify-center hover:bg-accent transition-colors"
          aria-label={collapsed ? 'Развернуть' : 'Свернуть'}
        >
          {collapsed ? (
            <ChevronsRight className="w-3.5 h-3.5 text-foreground" />
          ) : (
            <ChevronsLeft className="w-3.5 h-3.5 text-foreground" />
          )}
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <div className="space-y-1">
          <div className="relative">
            {activeSection === 'home' && (
              <div className="absolute left-0 top-0 w-1 h-10 bg-green-600 dark:bg-orange-500 rounded-r-full" />
            )}
            <button
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl hover:bg-sidebar-accent transition-colors ${
                collapsed ? 'justify-center' : ''
              } ${
                activeSection === 'home' 
                  ? 'text-green-700 dark:text-orange-500' 
                  : 'text-sidebar-foreground'
              }`}
              title={collapsed ? 'Главная' : ''}
              onClick={() => onSectionChange('home')}
            >
              <Home className="w-5 h-5 flex-shrink-0" />
              {!collapsed && <span className={`text-sm ${activeSection === 'home' ? 'font-semibold' : 'font-medium'}`}>Главная</span>}
            </button>
          </div>
          
          <div className="relative">
            {activeSection === 'reports' && (
              <div className="absolute left-0 top-0 w-1 h-10 bg-green-600 dark:bg-orange-500 rounded-r-full" />
            )}
            <button
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl hover:bg-sidebar-accent transition-colors ${
                collapsed ? 'justify-center' : ''
              } ${
                activeSection === 'reports' 
                  ? 'text-green-700 dark:text-orange-500' 
                  : 'text-sidebar-foreground'
              }`}
              title={collapsed ? 'Отчеты' : ''}
              onClick={() => onSectionChange('reports')}
            >
              <FileText className="w-5 h-5 flex-shrink-0" />
              {!collapsed && <span className={`text-sm ${activeSection === 'reports' ? 'font-semibold' : 'font-medium'}`}>Отчеты</span>}
            </button>
          </div>
        </div>
      </nav>

      {/* User Block */}
      <div className="p-4 border-t border-sidebar-border">
        <div className={`flex items-center gap-3 px-2 py-2 ${collapsed ? 'justify-center' : ''}`}>
          <div
            className="w-10 h-10 rounded-full bg-gradient-to-br from-green-500 to-green-600 dark:from-orange-400 dark:to-orange-600 flex items-center justify-center flex-shrink-0"
            title={collapsed ? 'Иван П.' : ''}
          >
            <span className="text-white font-medium text-sm">ИП</span>
          </div>
          {!collapsed && (
            <div className="flex-1 min-w-0">
              <div className="font-medium text-sidebar-foreground text-sm truncate">Иван П.</div>
              <div className="text-xs text-muted-foreground truncate">AppSec Engineer</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}