import { useState } from 'react';
import { Moon, Sun } from 'lucide-react';
import { SecuritySidebar } from '@/app/components/SecuritySidebar';
import { HierarchyPanel } from '@/app/components/HierarchyPanel';
import { ContentArea } from '@/app/components/ContentArea';
import { ReportsPage } from '@/app/components/ReportsPage';

export default function App() {
  const [selectedItem, setSelectedItem] = useState<{
    id: string;
    type: 'product' | 'project' | 'distribution';
    name: string;
  }>({
    id: 'drug-android-d2',
    type: 'distribution',
    name: 'ift_CI0002002.apk'
  });
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeSection, setActiveSection] = useState<'home' | 'reports'>('home');

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const toggleSidebar = () => {
    setSidebarCollapsed((prev) => !prev);
  };

  const handleNavigateToDistribution = (distributionId: string, distributionName: string) => {
    setSelectedItem({
      id: distributionId,
      type: 'distribution',
      name: distributionName
    });
    setActiveSection('home');
  };

  return (
    <div className={theme}>
      <div className="flex h-screen w-screen bg-background text-foreground overflow-hidden">
        {/* Theme Toggle Button - Fixed in top right */}
        <button
          onClick={toggleTheme}
          className="fixed top-4 right-4 z-50 p-3 rounded-xl bg-card border border-border shadow-lg hover:bg-accent transition-colors"
          aria-label="Переключить тему"
        >
          {theme === 'light' ? (
            <Moon className="w-5 h-5 text-foreground" />
          ) : (
            <Sun className="w-5 h-5 text-foreground" />
          )}
        </button>

        {/* Sidebar */}
        <SecuritySidebar 
          collapsed={sidebarCollapsed} 
          onToggleCollapse={toggleSidebar}
          activeSection={activeSection}
          onSectionChange={setActiveSection}
        />

        {activeSection === 'home' ? (
          <>
            {/* Hierarchy Panel */}
            <HierarchyPanel
              selectedItem={selectedItem}
              onItemSelect={setSelectedItem}
            />

            {/* Content Area */}
            <ContentArea selectedItem={selectedItem} />
          </>
        ) : (
          /* Reports Section */
          <ReportsPage onNavigateToDistribution={handleNavigateToDistribution} />
        )}
      </div>
    </div>
  );
}