
  # Security Scanning Tool Page

  This is a code bundle for Security Scanning Tool Page. The original project is available at https://www.figma.com/design/RzJxhq4c2ULPaEnGesFAm4/Security-Scanning-Tool-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  